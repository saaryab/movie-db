module.exports = [{
    title: 'Harry Potter and the Sorcerer\'s Stone (2001)',
    description: 'Harry Potter and the Sorcerer\'s Stone (2001)',
    genre: 'action',
    youtubeId: 'VyHV0BRtdxo'
  },
  {
    title: 'Harry Potter and the Chamber of Secrets (2002)',
    description: 'Harry Potter and the Chamber of Secrets (2002)',
    genre: 'action',
    youtubeId: '1bq0qff4iF8'
  },
  {
    title: 'Harry Potter and the Prisoner of Azkaban (2004)',
    description: 'Harry Potter and the Prisoner of Azkaban',
    genre: 'action',
    youtubeId: 'lAxgztbYDbs'
  },
  {
    title: 'Harry Potter and the Goblet of Fire (2005)',
    description: 'Harry Potter and the Goblet of Fire (2005)',
    genre: 'action',
    youtubeId: '3EGojp4Hh6I'
  },
  {
    title: 'The BFG',
    description: 'bfg',
    genre: 'disney',
    youtubeId: 'GZ0Bey4YUGI'
  },
  {
    title: 'COCO',
    description: 'COCO',
    genre: 'disney',
    youtubeId: 'jjudmcSxzpc'
  },
  {
    title: 'Tomorrowland',
    description: 'Tomorrowland',
    genre: 'disney',
    youtubeId: 'lNzukD8pS_s'
  }]